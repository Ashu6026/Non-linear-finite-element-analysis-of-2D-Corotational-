%% 2D Corotational (small strain, large deformation, without shear) Euler Bernoulli beams
...

clear all, clc,                 % Clearing the workspace and screen
%% FEA data
                                                      
% Parameters

% %example 1-cantilever tip load case
% load node.dat;                                                                %node matrix for toggle frame submitted seperately,4th coloumn represnt intial angle of beam at that node                                                                   
% load elem.dat;                                                                %element connectivity matrix for toggle frame submitted seperately
% N=size(elem,1);                                                               %calculates number of elements                
% dispbc = [1 1 1; 2 1 2;3 1 3];                                                % number, node number and dof to be fixed
% forces= [1 N 2 -10000];                                                       % number, node number, dof, and force magnitude
% N=size(elem,1);                                                               %calculates number of elemnts                        
% I(1:N,1)=  [1.3333];                                                          % moment of inertia matrix
% E(1:N,1) = [100*(10^3)];                                                      % Elastic Modulus
% A(1:N,1) = [4];                                                               % Cross sectional areas


% % example 2-toggle frame case
 load node.dat;                                                                  %node matrix for toggle frame submitted seperately,4th coloumn represnt intial angle of beam at that node
 load elem.dat;                                                                  %element connectivity matrix for toggle frame submitted seperately
 dispbc =[1 1 1;2 1 2;3 1 3;4 21 1;5 21 2;6 21 3];                               % number, node number and dof to be fixed
 forces= [1 11 2 -300];                                                          % number, node number, dof, and force magnitude
 I(1:size(elem,1)) = [0.0132651];                                                % moment of inertia matrix
 E(1:size(elem,1)) = [19971.4*(10^3)];                                           % Elastic Modulus
 A(1:size(elem,1)) = [0.408282];                                                 % Cross sectional areas


% % example 3-diamond frame case
% load node.dat;                                                                   %node matrix for toggle frame submitted seperately,4th coloumn represnt intial angle of beam at that node
% load elem.dat;                                                                   %element connectivity matrix for toggle frame submitted seperately
% forces=[1 11 2 -2.649226181400000e+06;];                                         % number, node number, dof, and force magnitude
% dispbc=[1 1 2;2 1 3;3 11 1];                                                     % number, node number and dof to be fixed
% I(1:size(elem,1)) = [0.0132651];                                                 %moment of inertia matrix
% E(1:size(elem,1)) = [19971.4*(10^3)];                                            % Elastic Modulus
% A(1:size(elem,1)) = [10];                                                        % Cross sectional areas

%% Some preprocessing --- for a generic FEM code based on displacement DOFs

Fo = zeros(3*size(node,1),1);                          % input force vector, and fixed degrees of freedom
for i = 1:size(forces,1), dof=3*(forces(i,2)-1)+forces(i,3);  Fo(dof) = forces(i,4); end
for i = 1:size(dispbc,1), dof=3*(dispbc(i,2)-1)+dispbc(i,3);  Fixdof(i) = dof; end
Freedof = setdiff(1:3*size(node,1),Fixdof);            % free degrees of freedom

%% Generalized coordinates/dofs --- ALL DISPLACEMENTS

v = zeros(3*size(node,1),1);                           % displacements initialized
for i=1:size(elem,1)
    nd1x=node(elem(i,2),2);        nd1y=node(elem(i,2),3);
    nd2x=node(elem(i,3),2);        nd2y=node(elem(i,3),3);
    lo(i) = sqrt( (nd2x-nd1x)^2 + (nd2y-nd1y)^2 );        
end

%% MOVIE generation and graph plotting...
OBJ1 = VideoWriter('Movie_2_truss_eg2_ARC2','MPEG-4');
OBJ2 = VideoWriter('Movie_2_truss_eg2_1_FD_ARC2','MPEG-4');
open(OBJ1); open(OBJ2);
disp_dof =3*forces(1,2)-1;                                         %degree of freedom to be plotted-change this to plot desired degree of freedom
%% Method and Iteration parameters

% ARC LENGTH --- CRISFIELD'S IMPLEMENTATION
    TOL = 1e-3;                % tolerance on iterative displacements
    psi = 0;        % 0 for cylindrical, 1 for spherical
    lambda = 0;   	% initial force increment, and change
    Del_lam = 0.01; % force increment
    del_l = 0.05;    % Arc length
    k_lam = 1;      % total number of lambda increments
    v = zeros(3*size(node,1),1);    % overall displacements...
    Delta_v = zeros(3*size(node,1),1);  % change in displacements
    while lambda <= 1
        k_iter = 0;
        v_p = v;                % previous displacements...
        lambda_p = lambda;      % previous load increment
        converge = 123456;    % dummy convergence value
        while converge > TOL,   % arc length iterations commence
           
            [g,Kt_Ga,ld,wd,thetaD,alpha,thetaO] = corotational_NFEM_mid(node,elem,E,I,A,lo,v_p+Delta_v,(lambda_p + Del_lam)*Fo);
           
            % DO APPLY Boundary Conditions
            Kt_free = Kt_Ga(Freedof,Freedof); 
            Fo_free = Fo(Freedof);
            Delta_v_free = Delta_v(Freedof);
            g_free = g(Freedof);
          
            par_g_par_lam = -Fo_free;
            
            % Inverting a matrix twice below --- Costly? 
            delta_v1 = 0*Delta_v;  % initialization (though not needed)
            delta_v1(Freedof) = -inv(Kt_free)*g_free;
            delta_v2 = 0*Delta_v;  % initialization (though not needed)
            delta_v2(Freedof) = -inv(Kt_free)*par_g_par_lam;
            
            % coefficients of the quadratic in del_lambda
            C2 = delta_v2'*delta_v2 + psi^2*Fo'*Fo;
            C1 = 2*(Delta_v + delta_v1)'*delta_v2 + 2*psi^2*Del_lam*Fo'*Fo;
            C0 = (Delta_v + delta_v1)'*(Delta_v + delta_v1) + psi^2*Del_lam^2*Fo'*Fo - del_l^2;
            
            % coefficients used to determine the angle between Delta_vn and Delta_v;
            C3 = Delta_v'*delta_v1 + Delta_v'*Delta_v + Del_lam*Del_lam;
            C4 = Delta_v'*delta_v2 + Del_lam;
            
            DISCRIM = C1^2 - 4*C0*C2;
            if DISCRIM > 0
                del_lam1 = -C1/2/C2 + sqrt(DISCRIM)/2/C2;
                del_lam2 = -C1/2/C2 - sqrt(DISCRIM)/2/C2;
                
                if (C3 + C4*del_lam2) > (C3 + C4*del_lam1),  del_lam = del_lam2;
                else,                                        del_lam = del_lam1;
                end
                
                Del_lam = Del_lam + del_lam; % force increment update
                % displacement update -- current displacement
                Delta_v = Delta_v + delta_v1 + del_lam*delta_v2;
                converge = (abs(g'*(delta_v1 + del_lam*delta_v2) ) );
                
                k_iter = k_iter + 1;
                fprintf('iter: %3d, del_lam: %3.4f, conv: %3.4e\n',k_iter,del_lam,converge);
                                            
            else
                fprintf('Imaginary ROOTS ---- '); pause; break;
            end
        end
        
        % overall updates --- lambda and generalized dofs
        lambda = lambda_p + Del_lam;
        v = v_p + Delta_v;
        [noden]= plot_NFEM_mid(node,elem,v,lo,ld,wd,thetaD,thetaO,alpha,1,'b','r');   pause(1e-6);
        figure(1); currFrame1 = getframe(gcf);   writeVideo(OBJ1,currFrame1); pause(1e-6);
        vstore(k_iter) = v(disp_dof); % vertical displacement @ hinge 2, say
        Fstore(k_iter) = lambda;
        figure(2);
        plot(vstore,Fstore,'k.','linewidth',2); hold on
        plot(vstore,Fstore,'kh','MarkerSize',14);
        xlabel('v ','FontSize',16); ylabel(' \lambda (input force)','FontSize',16);
        xlim auto;
        ylim auto;
        %axis([-1.8 0 -0.4 1.2]);
        grid on
        currFrame2 = getframe(gcf);   writeVideo(OBJ2,currFrame2); pause(1e-6);
        k_lam = k_lam + 1;
        fprintf('----------------------------------------------------\n');
    end
    close(OBJ1); close(OBJ2);
% % % %________________________________________________________________________

function [noden] = plot_NFEM_mid(node,elem,v,lo,ld,wd,thetaD,thetaO,alpha,figg,coli,colf)
%% Plotting initial and displaced configurations

figure(figg); clf; hold on;
% split displacements into two columns, x and y
v2c(:,1) = v(1:3:size(v,1));  v2c(:,2) = v(2:3:size(v,1));    v2c(:,3)= v(3:3:size(v,1));

sum_l = sum(lo);                                               % sum of truss lengths --- to specify the axes

% initial configuration
for i = 1:size(elem,1)
    
    data=[node(elem(i,2),2:3);node(elem(i,3),2:3)];
    TM1 = [cos(thetaO(i)) -sin(thetaO(i));sin(thetaO(i)) cos(thetaO(i))];
    wo(i:i+1,1) = [node(elem(i,2),4);node(elem(i,3),4)];
    n=1;
    for z=0:0.01:1
     xo(n)=lo(i)*z;
     yo(n)=lo(i)*((z.^3)-(2*z.^2)+z)*wo(i)+ld(i)*(z.^3-z.^2)*wo(i+1);
     xonew(n)=TM1(1,:)*[xo(n);yo(n)] + data(1,1);
     yonew(n)=TM1(2,:)*[xo(n);yo(n)]+  data(1,2);
     n=n+1;
    end
plot(xonew,yonew,'linewidth',4,'Color',coli)
end

% update nodal coordinates to reflect new configuration
% add x and y displacements to the original nodal coordinates 
noden = node;
 noden(:,2) =  node(:,2) + v2c(:,1);
 noden(:,3) =  node(:,3) + v2c(:,2);
 noden(:,4) =  node(:,4) + v2c(:,3);


% final element positions
for i = 1:size(elem,1)
    
    elemd=[noden(elem(i,2),2:3);noden(elem(i,3),2:3)];
    TM2 = [cos(thetaD(i)) -sin(thetaD(i));sin(thetaD(i)) cos(thetaD(i))];   %transfomation matrix
    wd(i:i+1,1) = [node(elem(i,2),4);node(elem(i,3),4)]+[v(3*(i-1)+3,1);v(3*i+3,1)]-alpha(i)*ones(2,1);
    
    n=1;
    for z=0:0.01:1
     xd(n)=ld(i)*z;
     yd(n)=ld(i)*((z.^3)-(2*z.^2)+z)*wd(i)+ld(i)*(z.^3-z.^2)*wd(i+1);
     xdnew(n)=TM2(1,:)*[xd(n);yd(n)] + elemd(1,1);
     ydnew(n)=TM2(2,:)*[xd(n);yd(n)]+  elemd(1,2);
     n=n+1;
    end
plot(xdnew,ydnew,'linewidth',4,'Color',colf)
end
xlim auto;
ylim auto;
end
%__________________________________________________________________________

%% function two trusses
function [g,Kt_Ga,ld,wd,thetaD,alpha,thetaO] = corotational_NFEM_mid(node,elem,E,I,A,lo,v,FORNET)

Kt_G=zeros(3*size(node,1),3*size(node,1));              %intitialize assembled tangent stiffnesss matrix
Fint_A=zeros(3*size(node,1),1);                         %intialize assembled global internal force matrix

for i=1:size(elem,1)                                    %loop for assemby started
%% Extracting original coordinates
x1 = node(i,2);  y1 = node(i,3);  wo_A(i)=node(i,4);
x2 = node(i+1,2);  y2 = node(i+1,3);  wo_B(i)=node(i+1,4);
%% Extracting displacements
u1 = v(3*i-2,1);    v1 = v(3*i-1,1);   b1=v(3*i,1);
u2 = v(3*i+1,1);    v2 = v(3*i+2,1);   b2=v(3*i+3,1);
%% Computing NEW LENGTHS of Trusses    
ld(i) = sqrt( (x2+u2-x1-u1)^2 + (y2+v2-y1-v1)^2 );
%% Defining some matrices
B1=(1/60)*[4 -1;-1 4];
B2=[4 2;2 4];
%% configuration parameters

Xo_AB=-(x1-x2);
Yo_AB=-(y1-y2);
thetaO(i)=atan2(Yo_AB,Xo_AB);
Xd_AB=-(x1+u1-x2-u2);
Yd_AB=-(y1+v1-y2-v2);
thetaD(i) = atan2(Yd_AB,Xd_AB);
alpha(i)=(thetaD(i)-thetaO(i));
wd_A(i)=wo_A(i)+b1-alpha(i);  
wd_B(i)=wo_B(i)+b2-alpha(i);
wo=[wo_A(i);wo_B(i)];
wd=[wd_A(i);wd_B(i)];
So=lo(i)*(1+wo'*B1*wo);
Sd=ld(i)*(1+wd'*B1*wd);
epsilonC=(Sd-So)/(So);
N=E(i)*A(i)*epsilonC;
sai=wd-wo;

%% internal force matrix

Fsai=(((2*N*((ld(i))^2)/So)*B1*wd) + ((E(i)*I(i)/ld(i))*B2*sai));
fld=(N*Sd/So-(E(i)*I(i)/ld(i).^2)*sai'*B2*sai);
Fi=[-fld;(Fsai(1)+Fsai(2))/ld(i);Fsai(1);fld;-((Fsai(1)+Fsai(2))/ld(i));Fsai(2)];       %local internal force matrix

%defining global internal force matrix
L1=[cos(thetaD(i)) -sin(thetaD(i)) 0;sin(thetaD(i)) cos(thetaD(i)) 0;0 0 1];
L2=[0 0 0;0 0 0;0 0 0];
lamda=[L1 L2;L2 L1];
Fi_G=lamda*Fi;

%assemby of global internal force matrix
Fint_A(3*i-2:3*i+3,1)=Fint_A(3*i-2:3*i+3,1)+Fi_G;


%% pertinent first partial derivatives

% del_lamda_del_thetaD
A1=[-sin(thetaD(i)) -cos(thetaD(i)) 0;cos(thetaD(i)) -sin(thetaD(i)) 0;0 0 0];
A2=[0 0 0;0 0 0;0 0 0];
del_lamda_del_thetaD=[A1 A2;A2 A1];


% D = del_alpha_del_ug_transpose(i)
 if alpha(i)>=0&&alpha(i)<=0.174533
     D=(1/(lo(i)*ld(i)*cos(alpha(i))))*[0 1;-1 0;0 0;0 -1;1 0;0 0]*[Xo_AB;Yo_AB]+(((Xo_AB)*(Yd_AB)-(Yo_AB)*(Xd_AB))/(lo(i)*((ld(i))^3)*cos(alpha(i))))*[1 0;0 1;0 0;-1 0;0 -1;0 0]*[Xd_AB;Yd_AB] ;
 else
     D=-(1/(lo(i)*ld(i)*sin(alpha(i))))*[-1 0;0 -1;0 0;1 0;0 1;0 0]*[Xo_AB;Yo_AB]+(((Xo_AB)*(Xd_AB)+(Yo_AB)*(Yd_AB))/(lo(i)*((ld(i)).^3)*sin(alpha(i))))*[-1 0;0 -1;0 0;1 0;0 1;0 0]*[Xd_AB;Yd_AB];
 end

del_ld_del_ua=-(Xd_AB/ld(i));
del_ld_del_va=-(Yd_AB/ld(i));
del_ld_del_Ba=0;
del_ld_del_ub=(Xd_AB/ld(i));
del_ld_del_vb=(Yd_AB/ld(i));
del_ld_del_Bb=0;

del_deltaL_del_ug=[del_ld_del_ua del_ld_del_va del_ld_del_Ba del_ld_del_ub del_ld_del_vb del_ld_del_Bb];
del_sai_del_ug=[-D(1) -D(2) 1 -D(4) -D(5) 0;-D(1) -D(2) 0 -D(4) -D(5) 1];
del_q_del_ug=[del_deltaL_del_ug;del_sai_del_ug];

del_ld_del_q=[1 0 0];
del_Sd_del_q=[1+wd'*B1*wd 2*ld(i)*wd'*B1];
del_wd_del_q=[0 1 0;0 0 1];                         %=del_sai_del_q 
del_N_del_q=(E(i)*A(i)/So)*del_Sd_del_q;

%del_fl_del_q
F1=(1/So)*(del_N_del_q*Sd+N*del_Sd_del_q)+(2*(E(i)*I(i)/(ld(i)^3))*sai'*B2*sai*del_ld_del_q)-((2*E(i)*I(i)/(ld(i)^2))*sai'*B2*del_wd_del_q); 
%del_Fsai_del_q
F2=(2*E(i)*A(i)*((ld(i)/So)^2)*B1*wd)*(del_Sd_del_q) + ((4*N*ld(i)*B1*wd/So)-(E(i)*I(i)*B2*sai/(ld(i)^2)))*(del_ld_del_q) + ((2*N*(ld(i)^2)/So)*B1+(E(i)*I(i)/ld(i))*B2)*(del_wd_del_q); 

del_Fi_del_q=[-F1;(1/ld(i))*(F2(1,:)+F2(2,:))-(1/ld(i)^2)*del_ld_del_q*(Fsai(1,:)+Fsai(2,:));F2(1,:);F1;-((1/ld(i))*(F2(1,:)+F2(2,:))-(1/ld(i)^2)*del_ld_del_q*(Fsai(1,:)+Fsai(2,:)));F2(2,:)];

%% Tangent Stiffness matrix calculation

del_Fi_del_Ug=del_Fi_del_q*del_q_del_ug;               
del_lamda_del_ug_Fi=((del_lamda_del_thetaD)*(D'*Fi));           %del_lamda_del_ug*Fi
lamda_del_Fi_del_Ug=(lamda*del_Fi_del_Ug);                      %lamda*del_Fi_del_ug
Kt=del_lamda_del_ug_Fi+lamda_del_Fi_del_Ug;

% assemby of global tangent stiffness matrix
Kt_G(3*i-2:3*i+3,3*i-2:3*i+3)=Kt_G(3*i-2:3*i+3,3*i-2:3*i+3)+Kt;

end
%% force residual
Kt_Ga=Kt_G;                                     %assembled tangent stiffness matrix
g=Fint_A-FORNET;                                %assembled global internal force matrix
end
%__________________________________________________________________________